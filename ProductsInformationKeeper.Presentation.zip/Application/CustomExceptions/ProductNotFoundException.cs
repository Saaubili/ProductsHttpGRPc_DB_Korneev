﻿namespace Application.CustomExceptions
{
    public class ProductNotFoundException:Exception
    {
        public ProductNotFoundException(string message) : base(message) {}
    }
}
